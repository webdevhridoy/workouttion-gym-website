import React from 'react';

const Footer = () => {
    return (
        <div>
            <div className="containter pt-5 pb-2">
                <p>Md Rafiqul Islam Creation. All reserve rights</p>
                Ⓒ 20202
            </div>
        </div>
    );
};

export default Footer;